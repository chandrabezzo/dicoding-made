package com.bezzo.moviecatalogue.features.setting

import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import androidx.appcompat.app.AlertDialog
import com.bezzo.core.base.BaseActivity
import com.bezzo.core.extension.toast
import com.bezzo.core.util.LocaleUtil
import com.bezzo.moviecatalogue.R
import com.bezzo.moviecatalogue.features.main.MainActivity
import kotlinx.android.synthetic.main.activity_setting.*
import org.koin.android.ext.android.inject
import kotlin.system.exitProcess

class SettingActivity : BaseActivity(), SettingViewContract {

    private val presenter: SettingPresenter<SettingViewContract> by inject()

    override fun onInitializedView(savedInstanceState: Bundle?) {
        presenter.onAttach(this)

        setSupportActionBar(toolbar)
        mActionBar = supportActionBar
        displayHome()
        setActionBarTitle(getString(R.string.app_name))
        toolbar.setNavigationOnClickListener {
            onNavigationClick()
        }

        if(LocaleUtil.getLanguage(this) == "en"){
            rb_indonesia.isChecked = false
            rb_english.isChecked = true
        }
        else {
            rb_indonesia.isChecked = true
            rb_english.isChecked = false
        }

        rb_indonesia.setOnCheckedChangeListener { _, value ->
            if(value){
                LocaleUtil.setLocale(this, "in")
            }
            else {
                LocaleUtil.setLocale(this, "en")
            }
        }

        rb_english.setOnCheckedChangeListener { _, value ->
            if(value){
                LocaleUtil.setLocale(this, "en")
            }
            else {
                LocaleUtil.setLocale(this, "in")
            }
        }
    }

    override fun onDestroy() {
        presenter.onDetach()
        super.onDestroy()
    }

    override fun setLayout(): Int {
        return R.layout.activity_setting
    }

    override fun onClickBack() {
        setResult(Activity.RESULT_OK)
        finish()
    }
}
