package com.bezzo.moviecatalogue.data.network

import com.bezzo.core.util.SchedulerProviderUtil

class ApiHelper constructor(schedulerProvider: SchedulerProviderUtil) {
}