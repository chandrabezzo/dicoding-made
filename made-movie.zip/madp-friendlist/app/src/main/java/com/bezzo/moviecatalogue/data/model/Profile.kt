package com.bezzo.moviecatalogue.data.model

data class Profile(
    val image: Int,
    val nama: String,
    val email: String
)