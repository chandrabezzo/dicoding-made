package com.bezzo.moviecatalogue.constanta

object AppConstant {
    const val DATA_MOVIE = "DataMovie"
}