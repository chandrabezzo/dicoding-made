package com.bezzo.core.data.session

/**
 * Created by bezzo on 02/02/18.
 */

object SessionConstants {
    val TOKEN = "Token"
    val USER_IDENTITY = "UserIdentity"
    val NO_PHONE = "NoPhone"
    val LATITUDE = "latitude"
    val LONGITUDE = "longitude"
}
