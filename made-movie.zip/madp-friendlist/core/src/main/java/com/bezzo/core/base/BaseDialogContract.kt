package com.bezzo.core.base

/**
 * Created by bezzo on 21/12/17.
 */

interface BaseDialogContract : BaseViewContract {

    fun dismissDialog(tag: String)

 }