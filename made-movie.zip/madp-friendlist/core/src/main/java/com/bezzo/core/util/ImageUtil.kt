package com.bezzo.core.util

import com.bumptech.glide.annotation.GlideModule
import com.bumptech.glide.module.*

@GlideModule
class ImageUtil : AppGlideModule()
