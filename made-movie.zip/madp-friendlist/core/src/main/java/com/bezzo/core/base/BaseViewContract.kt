package com.bezzo.core.base

/**
 * Created by bezzo on 21/12/17.
 */
interface BaseViewContract {
    fun handleError(case : Int, message : String)
}