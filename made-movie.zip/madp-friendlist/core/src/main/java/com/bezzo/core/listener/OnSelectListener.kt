package com.bezzo.core.listener

interface OnSelectListener {
    fun onSelected(selected : Boolean, position : Int)
}